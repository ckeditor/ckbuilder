CKEDITOR.plugins.setLang('lightbox', 'de',
{
    lightbox :
    {
        title : 'Lightbox',
        imgzoom : 'Bild zoomen',
        browse : 'zum blättern',
        boxnum : 'Box Nummer',
        mustint : 'Im Feld "Box Nummer" sind nur Zahlen erlaubt!'
    }
});
