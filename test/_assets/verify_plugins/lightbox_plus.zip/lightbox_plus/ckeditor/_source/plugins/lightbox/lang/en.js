CKEDITOR.plugins.setLang('lightbox', 'en',
{
    lightbox :
    {
        title : 'Lightbox',
        imgzoom : 'Zoom image',
        browse : 'Browse images',
        boxnum : 'Box number',
        mustint : 'Field "Box number" must be integer!'
    }
});
