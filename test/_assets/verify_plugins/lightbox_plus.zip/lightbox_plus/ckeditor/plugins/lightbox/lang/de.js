﻿/**************************************
    Webutler V2.1 - www.webutler.de
    Copyright (c) 2008 - 2011
    Autor: Sven Zinke
    Free for any use
    Lizenz: GPL
**************************************/

CKEDITOR.plugins.setLang('lightbox','de',{lightbox:{title:'Lightbox',imgzoom:'Bild zoomen',browse:'zum blättern',boxnum:'Box Nummer',mustint:'Im Feld "Box Nummer" sind nur Zahlen erlaubt!'}});
