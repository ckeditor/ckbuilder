CKEDITOR.plugins.setLang('youtube', 'en',
{
  youtube : 
  {
    title : "Embed Youtube Video",
    button : "Add Youtube Video",
    pasteMsg : "Please copy and paste the Youtube URL here<br>Please don't paste the embed code. Just Paste the URL.<br>example: http://www.youtube.com/embed/JK4oDgDicW8<br>http://youtu.be/JK4oDgDicW8"
  }
});
