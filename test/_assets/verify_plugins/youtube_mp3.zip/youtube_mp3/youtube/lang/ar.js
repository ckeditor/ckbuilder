﻿/*
 Mohammed Ahmed
 IntroTik
 Gaza, Palestine
 Email: maa@intro.ps
 Mobile: +970598505800
 Tel: +97082884379
 */
 
CKEDITOR.plugins.setLang('youtube', 'ar',
{
  youtube : 
  {
    title : "جلب فيديو من يوتيوب",
    button : "جلب يوتيوب",
    pasteMsg : "<spa dir=rtl style=direction:rtl>انسخ رابط اليوتيوب ثم قم بلصقه هنا <br>لا تقم بلصق كود embed. فقط الصق الرابط.<br>أمثلة:<br> http://www.youtube.com/embed/JK4oDgDicW8<br>http://youtu.be/JK4oDgDicW8</span>"
  }
});