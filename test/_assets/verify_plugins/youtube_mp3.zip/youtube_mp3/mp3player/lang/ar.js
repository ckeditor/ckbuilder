﻿/*
 Mohammed Ahmed
 IntroTik
 Gaza, Palestine
 Email: maa@intro.ps
 Mobile: +970598505800
 Tel: +97082884379
 */
CKEDITOR.plugins.setLang('mp3player', 'ar',
{
  mp3player : 
  {
    title : "ملف صوتي من نوع Mp3",
    button : "ملف صوتي Mp3",
    pasteMsg : "<span dir=rtl style=direction:rtl>الرجاء قم بنسخ رابط الملف الصوتي من نوع Mp3 ومن ثم قم بلصقه هنا.</span>"
  }
});