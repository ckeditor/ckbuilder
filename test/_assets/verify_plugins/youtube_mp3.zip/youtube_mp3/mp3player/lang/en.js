CKEDITOR.plugins.setLang('mp3player', 'en',
{
  mp3player : 
  {
    title : "Embed Mp3",
    button : "Add Mp3",
    pasteMsg : "Please copy and paste the Mp3 URL here"
  }
});
