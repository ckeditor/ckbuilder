
var codemirror_lang =
{
    button :
    {
        save : 'save',
        cancel : 'cancel',
        highlight : 'highlight on/off',
        undo : 'undo',
        redo : 'redo',
        reindent : 'reindent',
        search : 'search'
    },
    searchwins :
    {
        searchfor : 'search term:',
        tryagain : 'search again?',
        endofdoc : 'End of document reached. Start over?'
    }
};
