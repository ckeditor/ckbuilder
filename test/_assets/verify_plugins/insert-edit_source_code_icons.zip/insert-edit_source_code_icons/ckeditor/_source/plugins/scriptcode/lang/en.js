CKEDITOR.plugins.setLang('scriptcode', 'en',
{
    scriptcode :
    {
        title : 'insert code',
        editcode : 'edit code',
        dialog : 'insert/edit code'
    }
});
