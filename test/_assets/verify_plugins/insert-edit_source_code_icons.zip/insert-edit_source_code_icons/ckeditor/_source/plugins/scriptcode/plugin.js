
/**************************************
    Webutler V2.2 - www.webutler.de
    Copyright (c) 2008 - 2012
    Autor: Sven Zinke
    Free for any use
    Lizenz: GPL
**************************************/


(function()
{
    Array.prototype.PosInArray = function(needle)
    {
        for(var i = 0; i < this.length; i++) {
            if(needle === '{cke_protected}' + encodeURIComponent( this[i] ) ) {
                return i;
                break;
            }
        }
        return false;
    };
    
    function createCodePlaceholder( editor, element )
    {
    	var editordata = editor.getData();
        var phpmatches = editordata.match( /<\?[\s\S]*?\?>/gi );
        var scriptmatches = editordata.match( /<script[\s\S]*?<\/script>/gi );
        var phpPos = false;
        var jsPos = false;
    
        var attributes =
        {
    		src : CKEDITOR.getUrl( 'images/spacer.gif' ),
            'data-cke-real-element-type' : 'code',
            'data-cke-resizable' : false
        };
        
        if(phpmatches)
            phpPos = phpmatches.PosInArray( element );
        if(scriptmatches)
            jsPos = scriptmatches.PosInArray( element );
            
        attributes[ 'class' ] = '';
        attributes[ 'data-cke-realelement' ] = '';
        
        if( phpPos !== false ) {
            attributes[ 'class' ] = 'cke_phpcode';
            attributes[ 'data-cke-realelement' ] = encodeURIComponent( phpmatches[phpPos] );
            phpPos = false;
            return new CKEDITOR.htmlParser.element( 'img', attributes );
        }
        else if( jsPos !== false ) {
            attributes[ 'class' ] = 'cke_jscode';
            attributes[ 'data-cke-realelement' ] = encodeURIComponent( scriptmatches[jsPos] );
            jsPos = false;
            return new CKEDITOR.htmlParser.element( 'img', attributes );
        }
        else {
            return element;
        }
    }
    
    CKEDITOR.plugins.add( 'scriptcode',
    {
        lang : [CKEDITOR.lang.detect(CKEDITOR.config.language)],
        
    	init : function( editor )
    	{
    		editor.ui.addButton( 'ScriptCode',
    		{
    			label : editor.lang.scriptcode.title,
    			icon : this.path + 'inscode.png',
    			command : 'scriptcode'
    		});

            if( editor.name == 'metas' )
            {
                editor.addCommand( 'scriptcode' );
            }
            else
            {
                CKEDITOR.scriptLoader.load( codemirror_rootpath + 'codemirror/editor/js/codemirror.js' );
                CKEDITOR.scriptLoader.load( codemirror_rootpath + 'codemirror/lang/' + CKEDITOR.lang.detect(CKEDITOR.config.language) + '.js' );
                CKEDITOR.document.appendStyleSheet( codemirror_rootpath + 'codemirror/config/editor.css' );
                CKEDITOR.scriptLoader.load( codemirror_rootpath + 'codemirror/codemirror_config.js' );
                
        		editor.addMenuItems(
        		{
        			inscode :
        			{
        				label : editor.lang.scriptcode.editcode,
        				command : 'scriptcode',
                        icon : this.path + 'editcode.png',
        				group : 'inscode'
        			}
        		});
        		
        		editor.contextMenu.addListener( function( element, selection )
        		{
        			if( element && element.is( 'img' ) && !element.isReadOnly() )
                    {
                        if( element.data( 'cke-real-element-type' ) == 'code' )
                            return { inscode : CKEDITOR.TRISTATE_OFF };
                    }
        		});
        
            	editor.addCss(
            		'img.cke_jscode, img.cke_phpcode {' +
            			'background-position: center center;' +
            			'background-repeat: no-repeat;' +
            			'background-color: #FFFF00;' +
            			'display: inline;' +
            			'vertical-align: middle;' +
            		'}' +
            		'img.cke_jscode {' +
            			'background-image: url(' + CKEDITOR.getUrl( this.path + 'js_code.png' ) + ');' +
            			'width: 28px;' +
            			'height: 13px;' +
            		'}' +
            		'img.cke_phpcode {' +
            			'background-image: url(' + CKEDITOR.getUrl( this.path + 'php_code.png' ) + ');' +
            			'width: 37px;' +
            			'height: 13px;' +
            		'}'
        		);
    
        		editor.on( 'doubleclick', function( evt )
        		{
        			var element = evt.data.element;
        
        			if ( element.is( 'img' ) )
        			{
            			if ( element.data( 'cke-real-element-type' ) == 'code' )
            				evt.data.dialog = 'scriptcode';
        			}
        		});
        		
                editor.addCommand( 'scriptcode', new CKEDITOR.dialogCommand( 'scriptcode' ) ) ;
        		
        		CKEDITOR.dialog.add( 'scriptcode', this.path + 'dialogs/scriptcode.js' );
            }
    	},
    	afterInit : function( editor )
    	{
            if( editor.name != 'metas' )
            {
        		var dataProcessor = editor.dataProcessor,
        			dataFilter = dataProcessor && dataProcessor.dataFilter;
                
        		if ( dataFilter )
        		{
        			dataFilter.addRules(
        			{
        				comment : function( element )
        				{
        				    return createCodePlaceholder( editor, element );
        				}
        			}, 2);
        		}
            }
    	},
        requires : [ 'fakeobjects' ]
    });
})();
