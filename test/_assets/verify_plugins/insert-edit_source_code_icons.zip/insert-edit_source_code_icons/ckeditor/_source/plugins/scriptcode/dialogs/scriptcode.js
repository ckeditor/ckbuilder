
/**************************************
    Webutler V2.2 - www.webutler.de
    Copyright (c) 2008 - 2012
    Autor: Sven Zinke
    Free for any use
    Lizenz: GPL
**************************************/


(function()
{
    CKEDITOR.dialog.add( 'scriptcode', function( editor )
    {
        function reloadEditordata( editor ) {
    		var editordata = editor.getData();
    		editor.setData( editordata );
        }
        
    	return {
    		onOk : function()
    		{
    			var text = eval("scriptcodemirror_cke_" + editor.name + ".getCode()");
                if( text.replace(/^\s*|\s*$/g, "") != '' ) {
                    editor.insertHtml( text );
                    /*
        			if ( !this.editMode )
                        editor.insertHtml( text );
        			else {
                        var fromText = CKEDITOR.dom.element.createFromHtml( text );
                        fromText.replace( this.editCode );
        				//this.editCode.replace( text );
        			}
                    */
        			
        			reloadEditordata( editor );
                }
                else {
                    this.hide();
                }
            },
    		onShow : function()
    		{
    			var element = editor.getSelection().getSelectedElement();
    			
    			this.editMode = false;
                this.editCode = false;
    			
    			if ( element && element.data( 'cke-real-element-type' ) && element.data( 'cke-real-element-type' ) == 'code' )
    			{
    				this.editMode = true;
                    this.editCode = element;
    			}
                this.resize( 500, 350 );
                this.layout();
            },
    		title : editor.lang.scriptcode.dialog,
    		minWidth : 500,
    		minHeight : 350,
    		id : 'codepopupwin',
    		contents :
            [
        		{
        			id : 'tabcode',
        			label : '',
        			title : '',
        			elements :
                    [
        			    {
            				type : 'html',
        			        html : '<div class="codemirror_ckemenu" id="scriptcodemirror_ckemenu_' + editor.name + '"></div>',
                			'style' : 'height: 24px',
                    		onLoad : function()
                    		{
                                eval('codemirror_makeButton(codemirror_lang.button.highlight, "codemirror_syntax(scriptcodemirror_cke_' + editor.name + ', codemirror_stylesheet)", "highlight", "scriptcodemirror_ckemenu_' + editor.name + '");');
                                eval('codemirror_makeButton(codemirror_lang.button.undo, "scriptcodemirror_cke_' + editor.name + '.undo()", "undo", "scriptcodemirror_ckemenu_' + editor.name + '");');
                                eval('codemirror_makeButton(codemirror_lang.button.redo, "scriptcodemirror_cke_' + editor.name + '.redo()", "redo", "scriptcodemirror_ckemenu_' + editor.name + '");');
                                eval('codemirror_makeButton(codemirror_lang.button.reindent, "scriptcodemirror_cke_' + editor.name + '.reindent()", "reindent", "scriptcodemirror_ckemenu_' + editor.name + '");');
                                eval('codemirror_makeButton(codemirror_lang.button.search, "codemirror_searchpart(scriptcodemirror_cke_' + editor.name + ')", "search", "scriptcodemirror_ckemenu_' + editor.name + '");');
                    		}
                    	},
                        {
            				type : 'html',
            				id : 'htmlcodearea',
            		        html : '<div class="codemirror_ckebg" id="scriptcodemirror_ckebg_' + editor.name + '"><textarea id="scriptcodemirror_ckesource_' + editor.name + '" style="display: none"></textarea></div>',
                    		onShow : function()
                    		{
                    			var element = editor.getSelection().getSelectedElement();
                    			if( element && element.data( 'cke-real-element-type' ) && element.data( 'cke-real-element-type' ) == 'code' )
                                    document.getElementById('scriptcodemirror_ckesource_' + editor.name).value = decodeURIComponent( element.data( 'cke-realelement' ) );
                                
                                eval('scriptcodemirror_cke_' + editor.name + ' = CodeMirror.fromTextArea( "scriptcodemirror_ckesource_' + editor.name + '", {\n' +
                                    'height : "100%",\n' +
                                    'parserfile : codemirror_parserfile,\n' +
                                    'stylesheet : codemirror_stylesheet,\n' +
                                    'path : codemirror_rootpath + "codemirror/editor/js/",\n' +
                                    'continuousScanning : 500,\n' +
                                    'lineNumbers : true\n' +
                                '});\n');
                    		},
                    		onHide : function()
                    		{
                                document.getElementById('scriptcodemirror_ckesource_' + editor.name).value = '' ;
                                document.getElementById('scriptcodemirror_ckebg_' + editor.name).focus() ;
                                var codemirror = document.getElementById('scriptcodemirror_ckebg_' + editor.name).getElementsByTagName('div')[0];
                                document.getElementById('scriptcodemirror_ckebg_' + editor.name).removeChild(codemirror);
                            }
            			}
                    ]
                }
            ]
        }
    });
    
    CKEDITOR.on('instanceReady', function( evt )
    {
        eval("var scriptcodemirror_cke_" + evt.editor.name + ";");
    });

    CKEDITOR.dialog.on( 'resize', function( evt )
    {
        if(this == 'scriptcode')
        {
            if(document.getElementById('scriptcodemirror_ckebg_' + evt.editor.name)) {
            	var data = evt.data;
            	var width = data.width;
            	var height = data.height-46;
                document.getElementById('scriptcodemirror_ckebg_' + evt.editor.name).style.height = height + 'px' ;
            }
        }
    }, 'scriptcode', null, 100);
})();

