CKEDITOR.plugins.setLang('scriptcode', 'de',
{
    scriptcode :
    {
        title : 'Code einfügen',
        editcode : 'Code bearbeiten',
        dialog : 'Code einfügen/bearbeiten'
    }
});
