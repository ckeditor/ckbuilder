CKEDITOR.plugins.setLang('internpage', 'de',
{
    internpage :
    {
        internpage : 'Interne Seite'
    }
});
