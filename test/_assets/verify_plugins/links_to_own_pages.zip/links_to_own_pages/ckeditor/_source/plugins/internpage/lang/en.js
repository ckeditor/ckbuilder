CKEDITOR.plugins.setLang('internpage', 'en',
{
    internpage :
    {
        internpage : 'Internal page'
    }
});
