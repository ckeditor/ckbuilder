﻿/**************************************
    Webutler V2.1 - www.webutler.de
    Copyright (c) 2008 - 2011
    Autor: Sven Zinke
    Free for any use
    Lizenz: GPL
**************************************/

CKEDITOR.plugins.setLang('internpage','de',{internpage:{internpage:'Interne Seite'}});
