CKEDITOR.plugins.setLang('oEmbed', 'nl', {
	title : "Integratie van media-inhoud (foto's, video, content)",
    button : "Media-inhoud van externe websites",
    pasteUrl : "Geef een URL van een pagina in dat ondersteund wordt (Bijv.: YouTube, Flickr, Qik, Vimeo, Hulu, Viddler, MyOpera, etc.) ...",
	width : "Maximale breedte:",
	height : "Maximale hoogte:"
});
