CKEDITOR.plugins.setLang('oEmbed', 'de',
{
  oEmbed : 
  {
    title : "Medien Inhalt einbinden (Bilder, Video, Inhalt)",
    button : "Medien Inhalt von Verschiedenen Seiten einbinden",
    pasteUrl : "Fügen Sie eine Url (Gekürzte Urls werden auch erkannt) ein von einer Seite die Unterstützt wird (z.B.: YouTube, Flickr, Qik, Vimeo, Hulu, Viddler, MyOpera, etc.) ...",
	width : "Maximale Breite:",
	height : "Maximale Höhe:",
	found : " gefunden!"
  }
});
