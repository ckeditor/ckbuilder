CKEDITOR.plugins.setLang('oEmbed', 'en',
{
  oEmbed : 
  {
    title : "Embed Media Content (Photo, Video, Audio, Rich)",
    button : "Embed Media Content from Various Sites",
    pasteUrl : "Paste an URL (Also shortened URLs are supported) from one of the Supported Sites (e.g. YouTube, Flickr, Qik, Vimeo, Hulu, Viddler, MyOpera, etc.) here ...",
	width : "Max. Width:",
	height : "Max. Height:",
	found : " found!"
  }
});
