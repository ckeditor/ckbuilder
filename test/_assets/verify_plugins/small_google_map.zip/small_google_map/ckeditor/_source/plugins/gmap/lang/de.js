CKEDITOR.plugins.setLang('gmap', 'de',
{
    googlemaps :
    {
        title : 'Googlemap',
        addressnotfound : 'Die Adresse konnte nicht bestimmt werden!',
        wintitle : 'Googlemap einfügen/bearbeiten',
        setmarker : 'Der Marker muß gesetzt sein, um die Map einfügen zu können',
        address : 'Adresse',
        typeaddress : 'Adresse eingeben',
        search : 'Suchen',
        confirm : 'Soll der Infotext entfernt werden?',
        cancel : 'Abbrechen',
        accept : 'Übernehmen',
        marker : 'Marker',
        text : 'Text',
        width : 'Breite',
        nowidth : 'Sie haben keine Breite eingestellt',
        height : 'Höhe',
        noheight : 'Sie haben keine Höhe eingestellt'
    }
});
