﻿/**************************************
    Webutler V2.1 - www.webutler.de
    Copyright (c) 2008 - 2011
    Autor: Sven Zinke
    Free for any use
    Lizenz: GPL
**************************************/

CKEDITOR.plugins.setLang('gmap','de',{googlemaps:{title:'Googlemap',addressnotfound:'Die Adresse konnte nicht bestimmt werden!',wintitle:'Googlemap einfügen/bearbeiten',setmarker:'Der Marker muß gesetzt sein, um die Map einfügen zu können',address:'Adresse',typeaddress:'Adresse eingeben',search:'Suchen',confirm:'Soll der Infotext entfernt werden?',cancel:'Abbrechen',accept:'Übernehmen',marker:'Marker',text:'Text',width:'Breite',nowidth:'Sie haben keine Breite eingestellt',height:'Höhe',noheight:'Sie haben keine Höhe eingestellt'}});
