﻿/**************************************
    Webutler V2.1 - www.webutler.de
    Copyright (c) 2008 - 2011
    Autor: Sven Zinke
    Free for any use
    Lizenz: GPL
**************************************/

CKEDITOR.plugins.setLang('gmap','en',{googlemaps:{title:'Googlemap',addressnotfound:'Address was not found!',wintitle:'Googlemap insert/edit',setmarker:'Marker must be set to insert a map',address:'Address',typeaddress:'Please, type in an address',search:'search',confirm:'Really delete this info?',cancel:'cancel',accept:'apply',marker:'Marker',text:'Text',width:'Width',nowidth:'Please set a width',height:'Height',noheight:'Please set a height'}});
