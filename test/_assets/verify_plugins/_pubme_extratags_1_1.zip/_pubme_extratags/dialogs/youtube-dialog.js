/*
Copyright (c) 2011 - 2012, Pub-Me CMS - Michal Malenek. All rights reserved.
Custom YouTube plugin for CKEditor by CKSource - Frederico Knabben.
*/

(function ()
{
	pubmePluginName = '_pubme_extratags';
	tagName = 'youtube';

	CKEDITOR.dialog.add( tagName, function( editor )
	{
		var tagLang = PubMeCKEDITOR[pubmePluginName].getLang( editor, tagName );

		if ( typeof editor.config.pubmeyoutubeWidth == 'undefined' )
			editor.config.pubmeyoutubeWidth = 640; 
		if ( typeof editor.config.pubmeyoutubeHeight == 'undefined' )
			editor.config.pubmeyoutubeHeight = 360;

		return {
			title : tagLang.properties,
			minWidth : 400,
			minHeight : 200,
			contents :
			[
				{
					elements :
					[						
						{
							type : 'vbox',
							children :
							[
								{
									type : 'text',
									id : 'src',
									label : tagLang.source || 'Source',
									setup : PubMeCKEDITOR[pubmePluginName].loadValue,
									commit : PubMeCKEDITOR[pubmePluginName].commitValue
								},
								{
									type : 'html',
									html : tagLang.explainsource || ''
								},
								{
									type : 'hbox',
									widths : [ '50%', '50%' ],
									children :
									[
										{
											type : 'text',
											id : 'width',
											'default' : editor.config.pubmeyoutubeWidth,
											label : tagLang.width || 'Width',
											setup : PubMeCKEDITOR[pubmePluginName].loadValue,
											commit : PubMeCKEDITOR[pubmePluginName].commitValue
										},	 
										{
											type : 'text',
											id : 'height',
											'default' : editor.config.pubmeyoutubeHeight,
											label : tagLang.height || 'Height',
											setup : PubMeCKEDITOR[pubmePluginName].loadValue,
											commit : PubMeCKEDITOR[pubmePluginName].commitValue
										}
									]
								},
								{
									type : 'text',
									id : 'title',
									label : tagLang.title || 'Title',
									setup : PubMeCKEDITOR[pubmePluginName].loadValue,
									commit : PubMeCKEDITOR[pubmePluginName].commitValue
								}	 
							]
						}
					]
				}
			],
			onShow : function()
			{
				PubMeCKEDITOR[pubmePluginName].onShow ( this, editor, tagName );
			},
			onOk : function()
			{
				PubMeCKEDITOR[pubmePluginName].onOk ( this, editor, tagName );
			}

		}	
	});

})();