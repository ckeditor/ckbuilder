/*
Copyright (c) 2011, Pub-Me CMS - Michal Malenek. All rights reserved.
Custom YouTube plugin for CKEditor by CKSource - Frederico Knabben.
*/

if ( typeof(PubMeCKEDITOR) == "undefined" || PubMeCKEDITOR === null )
{
	var PubMeCKEDITOR = {};
}

(function()
{
	// name of the plugin
	var pubmePluginName = '_pubme_extratags';

	// definition of custom tags
	// var pubmeCustomTags = CKEDITOR.config.pubMeCustomTags || 
	var pubmeCustomTags = 
	{
		youtube : {
			dtd : [ '$empty','$inline','$body','div' ]
		}
	}; 
		
	// setttings end

	// inPubmeCustomTags checkes if the clicked tag is in the array definition
	function inPubmeCustomTags(needle)
	{
		for(var key in pubmeCustomTags)
			if(needle === key)
				return true;
		return false;
	}


	PubMeCKEDITOR[pubmePluginName] = {
		pluginName : pubmePluginName,
		getLang : function ( editor, pubmeTagName )
		{				
			// prevent "lang error"
			if ( !editor.lang.pubme )
				editor.lang.pubme = {};
			if ( !editor.lang.pubme[this.pluginName] )
				editor.lang.pubme[pubmePluginName] = {};
			if ( !editor.lang.pubme[this.pluginName][pubmeTagName] )
				editor.lang.pubme[this.pluginName][pubmeTagName] =
				{
					fakeObjectTitle : pubmeTagName,
					mainMenu : pubmeTagName,
					properties : pubmeTagName
				}
			var tagLang = editor.lang.pubme[ this.pluginName ][ pubmeTagName ];

			// update on hover title
			if ( !editor.lang.fakeobjects[pubmeTagName] )
				editor.lang.fakeobjects[pubmeTagName] = tagLang.fakeObjectTitle;

			return tagLang;
		},
		loadValue : function ( attributes )
		{
			if ( this.id in attributes )
				this.setValue ( attributes [ this.id ] );
		},
		commitValue : function ( attributes )
		{
			attributes [ this.id ] = this.getValue();
		},
		onShow : function( t, editor, tagName )
		{
			// Clear previously saved elements.
			t.fakeImage = t.iframeNode = null;

			var fakeImage = t.getSelectedElement();
			if ( fakeImage && fakeImage.data( 'cke-real-element-type' ) && fakeImage.data( 'cke-real-element-type' ) == tagName )
			{
				// custom tag needs to be parsed using "brutal force" - it is not possible to use inner/outerHTML and getAttributes methods
				// as custom tags are not included in dom for some reason
				// so we simply take the "realelement" string and search for quotes and apostrophes instead
				// We assume the format is <tag arg="something" arg2='something' /> or <tag arg="something" arg2='something'>something</tag> 
				t.fakeImage = fakeImage;
				var html = decodeURIComponent( fakeImage.data( 'cke-realelement' ) );
				var attributes = [];
				
				var i, i1, i2, attribute, attributeValue, useChar;
				
				i = html.indexOf(" ");
				html = html.substr ( i );

				while ( html.indexOf("=")>=0 )
				{
					i = html.indexOf("=");
					attribute = html.substr ( 0, i ).replace(/^\s+|\s+$/g,"");
					html = html.substr ( i+1 );
					
					i = -1;
					i1 =  html.indexOf("'");
					i2 =  html.indexOf('"');
					i3 =  html.indexOf('>');

					if (i1 >= 0)
						i = i1;

					if (i2 >=0 && (i2<i || i<0) )
						i = i2;

					if (i3 >=0 && (i3<i || i<0) )
						html = "";
					
					useChar = html.substr ( i, 1 );
					html = html.substr ( i + 1 );

					if ( html.indexOf( useChar )>=0 )
					{
						i = html.indexOf( useChar );
						attributeValue = html.substr ( 0, i ).replace(/^\s+|\s+$/g,"");
						html = html.substr ( i+1 );
						attributes [ attribute ] = attributeValue;
					}
					else
						html = "";
				}
				
				t.setupContent( attributes );
				
			}
		},
		onOk : function( t, editor, tagName )
		{
			var attributes = [];
			t.commitContent( attributes );
			
			var fakeElement = new CKEDITOR.dom.element( tagName );

			for (var i in attributes)
			{
				attributes [ i ] = attributes [ i ].replace(/^\s+|\s+$/g,"");
				if ( ( i == "width" || i == "height" ) && attributes [ i ] != "" )
				{
					attributes [ i ] = parseInt ( attributes [ i ] );
					if ( attributes [ i ] <= 0 || isNaN (attributes [ i ]) )
						attributes [i] = "";
				}
					
				if ( attributes[i] != "" )
					fakeElement.setAttribute( i, attributes[i] );
			}

			newFakeImage = editor.createFakeElement( fakeElement, 'cke_' + tagName, tagName, true );

			if ( t.fakeImage )
			{
				newFakeImage.replace( t.fakeImage );
				editor.getSelection().selectElement( newFakeImage );
			}
			else
				editor.insertElement( newFakeImage );

		}
	};
	
	// extract pubmeCustomTags and update dtd and needed "local" variables
	var pubmeTagNames = [];
	
	CKEDITOR.plugins.add( pubmePluginName,
	{
		init : function( editor )
		{
			// update custom tags definitions by config file
			pubmeCustomTags = editor.config.pubMeCustomTags || pubmeCustomTags;
			// register tag names
			for ( var tagName in pubmeCustomTags )
			{
				// append pubmeTagNames array
				pubmeTagNames.push ( tagName );
				
				// update custom tage dtd definition
				var dtd = CKEDITOR.dtd;
				var customDtd = pubmeCustomTags[ tagName ].dtd;
				dtd[tagName] = 1;
				for (var i in customDtd)
					dtd[customDtd[i]][tagName] = 1;		
			}	
		
			for (var tagIndex in pubmeTagNames)
			{
				pubmeTagName = pubmeTagNames[tagIndex]; 

				var tagLang = PubMeCKEDITOR[pubmePluginName].getLang( editor, pubmeTagName );
	
				// create new command
				editor.addCommand( pubmeTagName, new CKEDITOR.dialogCommand( pubmeTagName ) );

				// register icon
				var iconImage = this.path + 'images/' + pubmeTagName + '-icon.png';
				
				// main menu button
				editor.ui.addButton( pubmeTagName,
					{
						label : tagLang.mainMenu || pubmeTagName,
						command : pubmeTagName,
						icon : iconImage
					});
					
				// connect with dialog file
				CKEDITOR.dialog.add( pubmeTagName, this.path + 'dialogs/' + pubmeTagName + '-dialog.js' );
	
				// If the "menu" plugin is loaded, register the menu items.
				if ( editor.contextMenu )
				{
					editor.addMenuGroup( pubmeTagName );

					var newMenuItems = {};
					newMenuItems[ pubmeTagName ] =
					{
						label : tagLang.properties || pubmeTagName,
						icon : iconImage,
						command : pubmeTagName,
						group : pubmeTagName
					};
					editor.addMenuItems ( newMenuItems );					
				}
				
				// add css for replacement image	
				editor.addCss(
					'img.cke_' + pubmeTagName +
					'{' +
						'background-image: url(' + CKEDITOR.getUrl( this.path + 'images/' + pubmeTagName + '-placeholder.png' ) + ');' +
						'background-position: center center;' +
						'background-repeat: no-repeat;' +
						'border: 1px solid #a9a9a9;' +
						'width: 64px;' +
						'height: 64px;' +
					'}'
					);
			}

			// bind double click to object
			editor.on( 'doubleclick', function( evt )
				{
					var element = evt.data.element;
					if ( element.is( 'img' ) && inPubmeCustomTags(element.data( 'cke-real-element-type' ) )  )
						evt.data.dialog = element.data( 'cke-real-element-type' );
				});
				
			// register listeners for contextmenu
			if ( editor.contextMenu )
			{
				editor.contextMenu.addListener( function( element, selection )
					{
						if ( element && element.is( 'img' ) && !element.isReadOnly()
								&& inPubmeCustomTags(element.data( 'cke-real-element-type' ) ) )
							{
								var ret = {};
								ret[element.data( 'cke-real-element-type' )] = CKEDITOR.TRISTATE_OFF;
								return ret;
							}	
					});
			}

		},
				
		afterInit : function( editor )
		{
			var dataProcessor = editor.dataProcessor,
				dataFilter = dataProcessor && dataProcessor.dataFilter;

			if ( dataFilter )
			{
				var newRules = { elements : {} };

				for (var tagIndex in pubmeTagNames)
				{
					// TODO - there's a bug in the core - on init, it merges tags in the core into a single tag
					// (it displays just the first one, removes others - it is the case of built-in iframe plugin too)
					//     note - to be more precise, it turns <tag /><tag /> into <tag><tag></tag></tag>!!!
					pubmeTagName = pubmeTagNames[tagIndex];
					newRules.elements[ pubmeTagName ] = function ( element )
					{
						var fakeElement = editor.createFakeParserElement( element, 'cke_' + element.name, element.name, true );
						return fakeElement;
					};
				}
				dataFilter.addRules( newRules );
			}
		},

		requires : [ 'fakeobjects' ]
	});
})();