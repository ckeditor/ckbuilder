
var codemirror_lang =
{
    button :
    {
        save : 'Speichern',
        cancel : 'Abbrechen',
        highlight : 'Highlight ein/aus',
        undo : 'Rückgängig',
        redo : 'Wiederherstellen',
        reindent : 'Einzug korrigieren',
        search : 'Suche'
    },
    searchwins :
    {
        searchfor : 'Suche nach:',
        tryagain : 'Weiter suchen?',
        endofdoc : 'Ende des Dokuments erreicht. Suche am Anfang fortsetzen?'
    }
};
