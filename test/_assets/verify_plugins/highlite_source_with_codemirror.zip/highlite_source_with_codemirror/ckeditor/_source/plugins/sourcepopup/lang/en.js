CKEDITOR.plugins.setLang('sourcepopup', 'en',
{
    sourcepopup :
    {
        title : 'Edit source'
    }
});
