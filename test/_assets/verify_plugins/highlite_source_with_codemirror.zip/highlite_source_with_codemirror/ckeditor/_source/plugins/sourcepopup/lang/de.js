CKEDITOR.plugins.setLang('sourcepopup', 'de',
{
    sourcepopup :
    {
        title : 'Quellcode bearbeiten'
    }
});
